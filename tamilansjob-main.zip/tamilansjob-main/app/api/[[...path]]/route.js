import { MongoClient } from 'mongodb'
import { v4 as uuidv4 } from 'uuid'
import { NextResponse } from 'next/server'

// MongoDB connection
let client
let db

async function connectToMongo() {
  if (!client) {
    client = new MongoClient(process.env.MONGO_URL)
    await client.connect()
    db = client.db(process.env.DB_NAME)
  }
  return db
}

// Helper function to handle CORS
function handleCORS(response) {
  response.headers.set('Access-Control-Allow-Origin', process.env.CORS_ORIGINS || '*')
  response.headers.set('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS')
  response.headers.set('Access-Control-Allow-Headers', 'Content-Type, Authorization')
  response.headers.set('Access-Control-Allow-Credentials', 'true')
  return response
}

// OPTIONS handler for CORS
export async function OPTIONS() {
  return handleCORS(new NextResponse(null, { status: 200 }))
}

// Route handler function
async function handleRoute(request, { params }) {
  const { path = [] } = params
  const route = `/${path.join('/')}`
  const method = request.method

  try {
    const db = await connectToMongo()

    // Root endpoint
    if (route === '/' && method === 'GET') {
      return handleCORS(NextResponse.json({ message: "TamilansJob.com API" }))
    }

    // Districts endpoints
    if (route === '/districts' && method === 'GET') {
      const districts = await db.collection('districts').find({}).toArray()
      const cleanedDistricts = districts.map(({ _id, ...rest }) => rest)
      return handleCORS(NextResponse.json(cleanedDistricts))
    }

    if (route === '/districts' && method === 'POST') {
      const body = await request.json()
      const district = {
        id: uuidv4(),
        name_en: body.name_en,
        name_ta: body.name_ta || body.name_en,
        slug: body.slug || body.name_en.toLowerCase().replace(/\s+/g, '-'),
        createdAt: new Date()
      }
      await db.collection('districts').insertOne(district)
      return handleCORS(NextResponse.json(district))
    }

    // Qualifications endpoints
    if (route === '/qualifications' && method === 'GET') {
      const qualifications = await db.collection('qualifications').find({}).toArray()
      const cleanedQualifications = qualifications.map(({ _id, ...rest }) => rest)
      return handleCORS(NextResponse.json(cleanedQualifications))
    }

    if (route === '/qualifications' && method === 'POST') {
      const body = await request.json()
      const qualification = {
        id: uuidv4(),
        name_en: body.name_en,
        name_ta: body.name_ta || body.name_en,
        slug: body.slug || body.name_en.toLowerCase().replace(/\s+/g, '-'),
        order: body.order || 0,
        createdAt: new Date()
      }
      await db.collection('qualifications').insertOne(qualification)
      return handleCORS(NextResponse.json(qualification))
    }

    // Categories endpoints
    if (route === '/categories' && method === 'GET') {
      const categories = await db.collection('categories').find({}).toArray()
      const cleanedCategories = categories.map(({ _id, ...rest }) => rest)
      return handleCORS(NextResponse.json(cleanedCategories))
    }

    if (route === '/categories' && method === 'POST') {
      const body = await request.json()
      const category = {
        id: uuidv4(),
        name_en: body.name_en,
        name_ta: body.name_ta || body.name_en,
        slug: body.slug || body.name_en.toLowerCase().replace(/\s+/g, '-'),
        sector: body.sector,
        parentId: body.parentId || null,
        createdAt: new Date()
      }
      await db.collection('categories').insertOne(category)
      return handleCORS(NextResponse.json(category))
    }

    // Jobs endpoints
    if (route === '/jobs' && method === 'GET') {
      const url = new URL(request.url)
      const district = url.searchParams.get('district')
      const qualification = url.searchParams.get('qualification')
      const category = url.searchParams.get('category')
      const search = url.searchParams.get('search')
      const page = parseInt(url.searchParams.get('page') || '1')
      const limit = parseInt(url.searchParams.get('limit') || '10')
      const skip = (page - 1) * limit

      let query = { status: 'published' }

      if (district) {
        query.districtId = district
      }
      if (qualification) {
        query.qualificationIds = { $in: [qualification] }
      }
      if (category) {
        query.categoryIds = { $in: [category] }
      }
      if (search) {
        query.$or = [
          { title: { $regex: search, $options: 'i' } },
          { dept: { $regex: search, $options: 'i' } },
          { summary: { $regex: search, $options: 'i' } }
        ]
      }

      const jobs = await db.collection('jobs')
        .find(query)
        .sort({ postDate: -1 })
        .skip(skip)
        .limit(limit)
        .toArray()

      const totalJobs = await db.collection('jobs').countDocuments(query)
      const cleanedJobs = jobs.map(({ _id, ...rest }) => rest)

      return handleCORS(NextResponse.json({
        jobs: cleanedJobs,
        total: totalJobs,
        page,
        totalPages: Math.ceil(totalJobs / limit)
      }))
    }

    if (route === '/jobs' && method === 'POST') {
      const body = await request.json()
      const job = {
        id: uuidv4(),
        title: body.title,
        slug: body.slug || body.title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, ''),
        summary: body.summary || '',
        content: body.content || '',
        vacancies: body.vacancies || 0,
        dept: body.dept || '',
        sector: body.sector || '',
        board: body.board || '',
        jobType: body.jobType || 'permanent',
        payScale: body.payScale || '',
        salaryFrom: body.salaryFrom || 0,
        salaryTo: body.salaryTo || 0,
        ageMin: body.ageMin || 18,
        ageMax: body.ageMax || 35,
        fees: body.fees || 0,
        selectionProcess: body.selectionProcess || '',
        mode: body.mode || 'online',
        lastDate: body.lastDate ? new Date(body.lastDate) : null,
        postDate: body.postDate ? new Date(body.postDate) : new Date(),
        districtId: body.districtId || null,
        qualificationIds: body.qualificationIds || [],
        categoryIds: body.categoryIds || [],
        tags: body.tags || [],
        notifyPdfUrl: body.notifyPdfUrl || '',
        applyUrl: body.applyUrl || '',
        sourceUrl: body.sourceUrl || '',
        status: body.status || 'published',
        lang: body.lang || 'en',
        createdAt: new Date(),
        updatedAt: new Date()
      }
      await db.collection('jobs').insertOne(job)
      return handleCORS(NextResponse.json(job))
    }

    // Get single job by ID
    if (route.startsWith('/jobs/') && method === 'GET') {
      const jobId = path[1]
      const job = await db.collection('jobs').findOne({ id: jobId })
      if (!job) {
        return handleCORS(NextResponse.json({ error: 'Job not found' }, { status: 404 }))
      }
      const { _id, ...cleanedJob } = job
      return handleCORS(NextResponse.json(cleanedJob))
    }

    // Initialize seed data
    if (route === '/seed' && method === 'POST') {
      // Seed districts
      const districts = [
        { id: uuidv4(), name_en: 'Chennai', name_ta: 'சென்னை', slug: 'chennai', createdAt: new Date() },
        { id: uuidv4(), name_en: 'Coimbatore', name_ta: 'கோயம்புத்தூர்', slug: 'coimbatore', createdAt: new Date() },
        { id: uuidv4(), name_en: 'Madurai', name_ta: 'மதுரை', slug: 'madurai', createdAt: new Date() },
        { id: uuidv4(), name_en: 'Tiruchirappalli', name_ta: 'திருச்சிராப்பள்ளி', slug: 'tiruchirappalli', createdAt: new Date() },
        { id: uuidv4(), name_en: 'Salem', name_ta: 'சேலம்', slug: 'salem', createdAt: new Date() },
        { id: uuidv4(), name_en: 'Tirunelveli', name_ta: 'திருநெல்வேலி', slug: 'tirunelveli', createdAt: new Date() },
      ]
      
      await db.collection('districts').deleteMany({})
      await db.collection('districts').insertMany(districts)

      // Seed qualifications
      const qualifications = [
        { id: uuidv4(), name_en: '10th', name_ta: '10வது', slug: '10th', order: 1, createdAt: new Date() },
        { id: uuidv4(), name_en: '12th/HSC', name_ta: '12வது/பிளஸ் டூ', slug: '12th-hsc', order: 2, createdAt: new Date() },
        { id: uuidv4(), name_en: 'ITI', name_ta: 'ஐடிஐ', slug: 'iti', order: 3, createdAt: new Date() },
        { id: uuidv4(), name_en: 'Diploma', name_ta: 'டிப்ளமா', slug: 'diploma', order: 4, createdAt: new Date() },
        { id: uuidv4(), name_en: 'B.E/B.Tech', name_ta: 'பி.இ/பி.டெக்', slug: 'be-btech', order: 5, createdAt: new Date() },
        { id: uuidv4(), name_en: 'B.Sc', name_ta: 'பி.எஸ்சி', slug: 'bsc', order: 6, createdAt: new Date() },
        { id: uuidv4(), name_en: 'Any Degree', name_ta: 'ஏதேனும் பட்டம்', slug: 'any-degree', order: 7, createdAt: new Date() },
      ]
      
      await db.collection('qualifications').deleteMany({})
      await db.collection('qualifications').insertMany(qualifications)

      // Seed categories
      const categories = [
        { id: uuidv4(), name_en: 'TN Government', name_ta: 'தமிழ்நாடு அரசு', slug: 'tn-government', sector: 'government', parentId: null, createdAt: new Date() },
        { id: uuidv4(), name_en: 'TNPSC', name_ta: 'தமிழ்நாடு பொதுப்பணி ஆணையம்', slug: 'tnpsc', sector: 'government', parentId: null, createdAt: new Date() },
        { id: uuidv4(), name_en: 'TRB', name_ta: 'ஆசிரியர் தேர்வு வாரியம்', slug: 'trb', sector: 'education', parentId: null, createdAt: new Date() },
        { id: uuidv4(), name_en: 'Police', name_ta: 'காவல்துறை', slug: 'police', sector: 'police', parentId: null, createdAt: new Date() },
        { id: uuidv4(), name_en: 'Banking', name_ta: 'வங்கி', slug: 'banking', sector: 'banking', parentId: null, createdAt: new Date() },
        { id: uuidv4(), name_en: 'Central Government', name_ta: 'மத்திய அரசு', slug: 'central-government', sector: 'central', parentId: null, createdAt: new Date() },
      ]
      
      await db.collection('categories').deleteMany({})
      await db.collection('categories').insertMany(categories)

      // Create sample jobs
      const sampleJobs = [
        {
          id: uuidv4(),
          title: 'TNPSC Group 4 Recruitment 2025',
          slug: 'tnpsc-group-4-recruitment-2025',
          summary: 'Tamil Nadu Public Service Commission Group 4 posts recruitment notification',
          content: 'TNPSC has announced recruitment for Group 4 posts including Junior Assistant, Typist, and other clerical positions.',
          vacancies: 1958,
          dept: 'Tamil Nadu Public Service Commission',
          sector: 'government',
          board: 'TNPSC',
          jobType: 'permanent',
          payScale: '₹19,500 - ₹62,000',
          salaryFrom: 19500,
          salaryTo: 62000,
          ageMin: 18,
          ageMax: 30,
          fees: 150,
          selectionProcess: 'Written Exam + Interview',
          mode: 'online',
          lastDate: new Date('2025-02-15'),
          postDate: new Date(),
          districtId: districts[0].id, // Chennai
          qualificationIds: [qualifications[1].id], // 12th
          categoryIds: [categories[1].id], // TNPSC
          tags: ['group4', 'government', 'clerk'],
          notifyPdfUrl: 'https://example.com/tnpsc-group4.pdf',
          applyUrl: 'https://tnpsc.gov.in',
          sourceUrl: 'https://tnpsc.gov.in',
          status: 'published',
          createdAt: new Date(),
          updatedAt: new Date()
        },
        {
          id: uuidv4(),
          title: 'TRB Teacher Recruitment 2025',
          slug: 'trb-teacher-recruitment-2025',
          summary: 'Teachers Recruitment Board notification for Primary and Secondary teachers',
          content: 'TRB announces recruitment for various teaching positions in government schools across Tamil Nadu.',
          vacancies: 2340,
          dept: 'Teachers Recruitment Board',
          sector: 'education',
          board: 'TRB',
          jobType: 'permanent',
          payScale: '₹35,400 - ₹1,12,400',
          salaryFrom: 35400,
          salaryTo: 112400,
          ageMin: 21,
          ageMax: 40,
          fees: 500,
          selectionProcess: 'Written Exam',
          mode: 'online',
          lastDate: new Date('2025-03-01'),
          postDate: new Date(),
          districtId: districts[1].id, // Coimbatore
          qualificationIds: [qualifications[4].id], // B.E/B.Tech
          categoryIds: [categories[2].id], // TRB
          tags: ['teacher', 'education', 'trb'],
          notifyPdfUrl: 'https://example.com/trb-teacher.pdf',
          applyUrl: 'https://trb.tn.gov.in',
          sourceUrl: 'https://trb.tn.gov.in',
          status: 'published',
          createdAt: new Date(),
          updatedAt: new Date()
        }
      ]

      await db.collection('jobs').deleteMany({})
      await db.collection('jobs').insertMany(sampleJobs)

      return handleCORS(NextResponse.json({ 
        message: 'Seed data created successfully',
        counts: {
          districts: districts.length,
          qualifications: qualifications.length,
          categories: categories.length,
          jobs: sampleJobs.length
        }
      }))
    }

    // Route not found
    return handleCORS(NextResponse.json(
      { error: `Route ${route} not found` }, 
      { status: 404 }
    ))

  } catch (error) {
    console.error('API Error:', error)
    return handleCORS(NextResponse.json(
      { error: "Internal server error", details: error.message }, 
      { status: 500 }
    ))
  }
}

// Export all HTTP methods
export const GET = handleRoute
export const POST = handleRoute
export const PUT = handleRoute
export const DELETE = handleRoute
export const PATCH = handleRoute