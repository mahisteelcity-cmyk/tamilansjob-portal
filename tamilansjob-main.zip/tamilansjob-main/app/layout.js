import './globals.css'

export const metadata = {
  title: 'TamilansJob.com - Tamil Nadu Government Jobs & Recruitment Updates',
  description: 'Find latest Tamil Nadu government job notifications, recruitment updates, and career opportunities. Filter by district, qualification, and category. Apply for TNPSC, TRB, Police, and other government jobs.',
  keywords: 'Tamil Nadu jobs, TNPSC, TRB, government jobs, recruitment, Chennai jobs, Coimbatore jobs, Tamil Nadu recruitment',
  authors: [{ name: 'TamilansJob.com' }],
  creator: 'TamilansJob.com',
  publisher: 'TamilansJob.com',
  robots: {
    index: true,
    follow: true,
  },
  openGraph: {
    title: 'TamilansJob.com - Tamil Nadu Government Jobs',
    description: 'Find latest Tamil Nadu government job notifications and recruitment updates',
    url: 'https://tamilansjob.com',
    siteName: 'TamilansJob.com',
    type: 'website',
    locale: 'en_IN',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'TamilansJob.com - Tamil Nadu Government Jobs',
    description: 'Find latest Tamil Nadu government job notifications and recruitment updates',
    creator: '@tamilansjob',
  },
  alternates: {
    canonical: 'https://tamilansjob.com',
  },
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#2563eb" />
      </head>
      <body className="antialiased">
        {children}
      </body>
    </html>
  )
}