'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CalendarDays, MapPin, Users, GraduationCap, Building, Clock, ExternalLink, FileText } from 'lucide-react'

export default function App() {
  const [jobs, setJobs] = useState([])
  const [districts, setDistricts] = useState([])
  const [qualifications, setQualifications] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    district: '',
    qualification: '',
    category: '',
    search: ''
  })
  const [pagination, setPagination] = useState({ page: 1, totalPages: 1, total: 0 })
  const [selectedJob, setSelectedJob] = useState(null)

  // Initialize data on component mount
  useEffect(() => {
    initializeData()
  }, [])

  // Fetch jobs when filters change
  useEffect(() => {
    fetchJobs()
  }, [filters, pagination.page])

  const initializeData = async () => {
    try {
      // First seed the data
      await fetch('/api/seed', { method: 'POST' })
      
      // Then fetch all reference data
      const [districtsRes, qualificationsRes, categoriesRes] = await Promise.all([
        fetch('/api/districts'),
        fetch('/api/qualifications'),
        fetch('/api/categories')
      ])
      
      const [districtsData, qualificationsData, categoriesData] = await Promise.all([
        districtsRes.json(),
        qualificationsRes.json(),
        categoriesRes.json()
      ])
      
      setDistricts(districtsData)
      setQualifications(qualificationsData)
      setCategories(categoriesData)
      
      setLoading(false)
    } catch (error) {
      console.error('Error initializing data:', error)
      setLoading(false)
    }
  }

  const fetchJobs = async () => {
    try {
      const params = new URLSearchParams()
      if (filters.district) params.append('district', filters.district)
      if (filters.qualification) params.append('qualification', filters.qualification)
      if (filters.category) params.append('category', filters.category)
      if (filters.search) params.append('search', filters.search)
      params.append('page', pagination.page.toString())
      params.append('limit', '10')
      
      const response = await fetch(`/api/jobs?${params}`)
      const data = await response.json()
      
      setJobs(data.jobs || [])
      setPagination({
        page: data.page || 1,
        totalPages: data.totalPages || 1,
        total: data.total || 0
      })
    } catch (error) {
      console.error('Error fetching jobs:', error)
    }
  }

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }))
    setPagination(prev => ({ ...prev, page: 1 })) // Reset to first page
  }

  const clearFilters = () => {
    setFilters({ district: '', qualification: '', category: '', search: '' })
    setPagination(prev => ({ ...prev, page: 1 }))
  }

  const formatDate = (dateString) => {
    if (!dateString) return 'N/A'
    return new Date(dateString).toLocaleDateString('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    })
  }

  const isLastDateSoon = (lastDate) => {
    if (!lastDate) return false
    const today = new Date()
    const deadline = new Date(lastDate)
    const diffTime = deadline - today
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    return diffDays <= 7 && diffDays > 0
  }

  const isLastDateToday = (lastDate) => {
    if (!lastDate) return false
    const today = new Date().toDateString()
    const deadline = new Date(lastDate).toDateString()
    return today === deadline
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-lg text-gray-600">Loading TamilansJob.com...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-lg border-b-4 border-blue-600">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-blue-600 text-white p-3 rounded-lg">
                <Building className="h-8 w-8" />
              </div>
              <div>
                <h1 className="text-3xl font-bold text-gray-900">TamilansJob.com</h1>
                <p className="text-gray-600">Tamil Nadu Government Jobs & Recruitment Updates</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-6 text-sm text-gray-600">
              <div className="flex items-center space-x-1">
                <Users className="h-4 w-4" />
                <span>{pagination.total} Active Jobs</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span>Updated Daily</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-blue-600 text-white">
        <div className="container mx-auto px-4">
          <ul className="flex space-x-8 py-3 text-sm">
            <li className="hover:text-blue-200 cursor-pointer font-medium">Home</li>
            <li className="hover:text-blue-200 cursor-pointer">Jobs by District</li>
            <li className="hover:text-blue-200 cursor-pointer">Jobs by Qualification</li>
            <li className="hover:text-blue-200 cursor-pointer">Categories</li>
            <li className="hover:text-blue-200 cursor-pointer">Latest Notifications</li>
            <li className="hover:text-blue-200 cursor-pointer">Contact Us</li>
          </ul>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-8">
        {/* Filters Section */}
        <Card className="mb-8 shadow-lg border-0">
          <CardHeader className="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
            <CardTitle className="flex items-center space-x-2">
              <GraduationCap className="h-5 w-5" />
              <span>Find Your Dream Government Job</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-4">
              <Input
                placeholder="Search jobs, departments..."
                value={filters.search}
                onChange={(e) => handleFilterChange('search', e.target.value)}
                className="border-gray-300 focus:border-blue-500"
              />
              
              <Select value={filters.district} onValueChange={(value) => handleFilterChange('district', value)}>
                <SelectTrigger className="border-gray-300">
                  <SelectValue placeholder="Select District" />
                </SelectTrigger>
                <SelectContent>
                  {districts.map(district => (
                    <SelectItem key={district.id} value={district.id}>
                      {district.name_en} ({district.name_ta})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filters.qualification} onValueChange={(value) => handleFilterChange('qualification', value)}>
                <SelectTrigger className="border-gray-300">
                  <SelectValue placeholder="Select Qualification" />
                </SelectTrigger>
                <SelectContent>
                  {qualifications.map(qual => (
                    <SelectItem key={qual.id} value={qual.id}>
                      {qual.name_en} ({qual.name_ta})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={filters.category} onValueChange={(value) => handleFilterChange('category', value)}>
                <SelectTrigger className="border-gray-300">
                  <SelectValue placeholder="Select Category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map(category => (
                    <SelectItem key={category.id} value={category.id}>
                      {category.name_en} ({category.name_ta})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button onClick={clearFilters} variant="outline" className="border-gray-300 hover:bg-gray-50">
                Clear Filters
              </Button>
            </div>

            {/* Active Filters */}
            {(filters.district || filters.qualification || filters.category || filters.search) && (
              <div className="flex flex-wrap gap-2 mt-4">
                <span className="text-sm text-gray-600">Active filters:</span>
                {filters.search && <Badge variant="secondary">Search: {filters.search}</Badge>}
                {filters.district && (
                  <Badge variant="secondary">
                    District: {districts.find(d => d.id === filters.district)?.name_en}
                  </Badge>
                )}
                {filters.qualification && (
                  <Badge variant="secondary">
                    Qualification: {qualifications.find(q => q.id === filters.qualification)?.name_en}
                  </Badge>
                )}
                {filters.category && (
                  <Badge variant="secondary">
                    Category: {categories.find(c => c.id === filters.category)?.name_en}
                  </Badge>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Results Summary */}
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            Latest Job Opportunities
            <span className="text-lg font-normal text-gray-600 ml-2">
              ({pagination.total} jobs found)
            </span>
          </h2>
          <div className="text-sm text-gray-600">
            Page {pagination.page} of {pagination.totalPages}
          </div>
        </div>

        {/* Jobs Grid */}
        {jobs.length === 0 ? (
          <Card className="shadow-lg border-0">
            <CardContent className="text-center py-12">
              <Building className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No Jobs Found</h3>
              <p className="text-gray-600">Try adjusting your search filters to find more opportunities.</p>
              <Button onClick={clearFilters} className="mt-4" variant="outline">
                Clear All Filters
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-1">
            {jobs.map(job => (
              <Card key={job.id} className="shadow-lg border-0 hover:shadow-xl transition-all duration-200 overflow-hidden">
                <CardContent className="p-0">
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-4">
                      <div className="flex-1">
                        <h3 className="text-xl font-bold text-gray-900 mb-2 hover:text-blue-600 cursor-pointer">
                          {job.title}
                        </h3>
                        <p className="text-gray-600 mb-3">{job.summary}</p>
                        
                        <div className="flex flex-wrap gap-3 text-sm text-gray-600 mb-4">
                          <div className="flex items-center space-x-1">
                            <Building className="h-4 w-4" />
                            <span>{job.dept}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Users className="h-4 w-4" />
                            <span>{job.vacancies} Vacancies</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MapPin className="h-4 w-4" />
                            <span>{districts.find(d => d.id === job.districtId)?.name_en || 'All Districts'}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <CalendarDays className="h-4 w-4" />
                            <span>Last Date: {formatDate(job.lastDate)}</span>
                          </div>
                        </div>

                        <div className="flex flex-wrap gap-2 mb-4">
                          {isLastDateToday(job.lastDate) && (
                            <Badge variant="destructive" className="animate-pulse">Last Date Today!</Badge>
                          )}
                          {isLastDateSoon(job.lastDate) && !isLastDateToday(job.lastDate) && (
                            <Badge variant="outline" className="border-orange-500 text-orange-600">Ending Soon</Badge>
                          )}
                          <Badge variant="outline" className="capitalize">{job.jobType}</Badge>
                          <Badge variant="secondary">{job.mode}</Badge>
                          {job.tags.map(tag => (
                            <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                          ))}
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-gray-700">Salary:</span>
                            <div className="text-green-600 font-semibold">{job.payScale}</div>
                          </div>
                          <div>
                            <span className="font-medium text-gray-700">Age Limit:</span>
                            <div className="text-gray-900">{job.ageMin} - {job.ageMax} years</div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-wrap gap-2 pt-4 border-t border-gray-100">
                      <Dialog>
                        <DialogTrigger asChild>
                          <Button variant="default" size="sm" className="bg-blue-600 hover:bg-blue-700">
                            View Details
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
                          <DialogHeader>
                            <DialogTitle className="text-xl">{job.title}</DialogTitle>
                          </DialogHeader>
                          <JobDetails job={job} districts={districts} qualifications={qualifications} />
                        </DialogContent>
                      </Dialog>
                      
                      {job.applyUrl && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={job.applyUrl} target="_blank" rel="noopener noreferrer">
                            <ExternalLink className="h-4 w-4 mr-1" />
                            Apply Now
                          </a>
                        </Button>
                      )}
                      
                      {job.notifyPdfUrl && (
                        <Button variant="outline" size="sm" asChild>
                          <a href={job.notifyPdfUrl} target="_blank" rel="noopener noreferrer">
                            <FileText className="h-4 w-4 mr-1" />
                            Notification PDF
                          </a>
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Pagination */}
        {pagination.totalPages > 1 && (
          <div className="flex justify-center items-center space-x-2 mt-8">
            <Button
              variant="outline"
              onClick={() => setPagination(prev => ({ ...prev, page: Math.max(1, prev.page - 1) }))}
              disabled={pagination.page === 1}
            >
              Previous
            </Button>
            
            <div className="flex space-x-1">
              {Array.from({ length: Math.min(5, pagination.totalPages) }, (_, i) => {
                const pageNum = i + 1
                return (
                  <Button
                    key={pageNum}
                    variant={pagination.page === pageNum ? "default" : "outline"}
                    size="sm"
                    onClick={() => setPagination(prev => ({ ...prev, page: pageNum }))}
                    className="w-10"
                  >
                    {pageNum}
                  </Button>
                )
              })}
            </div>
            
            <Button
              variant="outline"
              onClick={() => setPagination(prev => ({ ...prev, page: Math.min(prev.totalPages, prev.page + 1) }))}
              disabled={pagination.page === pagination.totalPages}
            >
              Next
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}

// Job Details Component
function JobDetails({ job, districts, qualifications }) {
  return (
    <div className="space-y-6">
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="eligibility">Eligibility</TabsTrigger>
          <TabsTrigger value="process">Selection Process</TabsTrigger>
        </TabsList>
        
        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Department</h4>
              <p className="text-gray-900">{job.dept}</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Total Vacancies</h4>
              <p className="text-gray-900 font-semibold">{job.vacancies}</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Salary Range</h4>
              <p className="text-green-600 font-semibold">{job.payScale}</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Application Mode</h4>
              <p className="text-gray-900 capitalize">{job.mode}</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Last Date</h4>
              <p className="text-red-600 font-semibold">{new Date(job.lastDate).toLocaleDateString('en-IN')}</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Application Fees</h4>
              <p className="text-gray-900">₹{job.fees}</p>
            </div>
          </div>
          
          {job.content && (
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Job Description</h4>
              <p className="text-gray-900">{job.content}</p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="eligibility" className="space-y-4">
          <div className="grid grid-cols-1 gap-4">
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Age Limit</h4>
              <p className="text-gray-900">{job.ageMin} - {job.ageMax} years</p>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Required Qualification</h4>
              <div className="flex flex-wrap gap-2">
                {job.qualificationIds.map(qualId => {
                  const qual = qualifications.find(q => q.id === qualId)
                  return qual ? <Badge key={qualId} variant="outline">{qual.name_en}</Badge> : null
                })}
              </div>
            </div>
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Posting Location</h4>
              <p className="text-gray-900">
                {districts.find(d => d.id === job.districtId)?.name_en || 'All Districts of Tamil Nadu'}
              </p>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="process" className="space-y-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <h4 className="font-medium text-gray-700">Selection Process</h4>
              <p className="text-gray-900">{job.selectionProcess || 'As per notification'}</p>
            </div>
            
            <div className="grid grid-cols-1 gap-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h5 className="font-medium text-blue-800 mb-2">Important Links</h5>
                <div className="space-y-2">
                  {job.notifyPdfUrl && (
                    <a href={job.notifyPdfUrl} target="_blank" rel="noopener noreferrer" 
                       className="flex items-center space-x-2 text-blue-600 hover:text-blue-800">
                      <FileText className="h-4 w-4" />
                      <span>Official Notification PDF</span>
                    </a>
                  )}
                  {job.applyUrl && (
                    <a href={job.applyUrl} target="_blank" rel="noopener noreferrer" 
                       className="flex items-center space-x-2 text-blue-600 hover:text-blue-800">
                      <ExternalLink className="h-4 w-4" />
                      <span>Apply Online</span>
                    </a>
                  )}
                  {job.sourceUrl && (
                    <a href={job.sourceUrl} target="_blank" rel="noopener noreferrer" 
                       className="flex items-center space-x-2 text-blue-600 hover:text-blue-800">
                      <ExternalLink className="h-4 w-4" />
                      <span>Official Website</span>
                    </a>
                  )}
                </div>
              </div>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}